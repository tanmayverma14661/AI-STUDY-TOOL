import os

# Optional fallback for users who want to paste key directly here.
LOCAL_GEMINI_API_KEY = ""

# Priority: environment variable, then local fallback.
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip() or LOCAL_GEMINI_API_KEY.strip()
