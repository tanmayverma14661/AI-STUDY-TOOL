import os
import re
from flask import Flask, render_template, request
import google.generativeai as genai
from config import GEMINI_API_KEY

def get_gemini_key(form_key: str = "") -> str:
    """
    Key priority:
    1) API key submitted from Study Plan form
    2) GEMINI_API_KEY environment variable
    3) config.py GEMINI_API_KEY
    """
    return (form_key or os.getenv("GEMINI_API_KEY", "") or GEMINI_API_KEY or "").strip()

app = Flask(__name__)


def get_gemini_model(form_key: str = ""):
    key = get_gemini_key(form_key)
    if not key:
        return None, "Gemini API key is missing. Add it in config.py, environment variable, or in the form field."
    genai.configure(api_key=key)
    return genai.GenerativeModel("gemini-1.5-flash"), None


def parse_questions(raw_text: str):
    lines = [ln.strip() for ln in raw_text.splitlines() if ln.strip()]
    cleaned = []
    for line in lines:
        normalized = re.sub(r"^\d+[\).\-\s]*", "", line).strip()
        normalized = re.sub(r"^[\-\*\u2022]\s*", "", normalized).strip()
        if normalized:
            cleaned.append(normalized)
    if cleaned:
        return cleaned[:8]
    return [raw_text.strip()] if raw_text.strip() else []

# **Home Page**
@app.route("/")
def home():
    return render_template("index.html")

# **Question Generator Page**
@app.route("/question-generator", methods=["GET", "POST"])
def generate_questions():
    if request.method == "GET":
        return render_template("question_generator.html")

    paragraph = request.form.get("paragraph", "").strip()

    if not paragraph:
        return render_template("question_generator.html", error="Please enter a paragraph.", paragraph=paragraph)

    try:
        model, error = get_gemini_model()
        if error:
            return render_template("question_generator.html", error=error, paragraph=paragraph)
        prompt = (
            "Generate 5 clear practice questions from the text below. "
            "Return each question on a new line only.\n\n"
            f"Text:\n{paragraph}"
        )
        response = model.generate_content(prompt)
        all_questions = parse_questions(response.text or "")
        if not all_questions:
            return render_template("question_generator.html", error="No questions generated. Try with more detailed text.", paragraph=paragraph)
        return render_template("question_generator_result.html", questions=all_questions)
    except Exception as e:
        return render_template("question_generator.html", error=f"Question generation failed: {e}", paragraph=paragraph)

# **Summarization Page**
@app.route("/summarizer", methods=["GET", "POST"])
def summarize_text():
    if request.method == "GET":
        return render_template("summarizer.html")

    user_text = request.form.get("user_text", "").strip()

    if not user_text:
        return render_template("summarizer.html", error="Please enter text to summarize.", user_text=user_text)

    try:
        model, error = get_gemini_model()
        if error:
            return render_template("summarizer.html", error=error, user_text=user_text)
        prompt = (
            "Summarize the following text in 5-8 concise bullet points. "
            "Keep important facts.\n\n"
            f"Text:\n{user_text}"
        )
        response = model.generate_content(prompt)
        summary = (response.text or "").strip()
        if not summary:
            return render_template("summarizer.html", error="Could not generate summary. Please try again.", user_text=user_text)
        return render_template("summarizer_result.html", summary=summary)
    except Exception as e:
        return render_template("summarizer.html", error=f"Summarization failed: {e}", user_text=user_text)

# **Question Answering Page**
@app.route("/answer-question", methods=["GET", "POST"])
def answer_question():
    if request.method == "GET":
        return render_template("qa.html")

    context = request.form.get("context", "").strip()
    question = request.form.get("question", "").strip()

    if not context or not question:
        return render_template("qa.html", error="Please provide both context and question.", context=context, question=question)

    try:
        model, error = get_gemini_model()
        if error:
            return render_template("qa.html", error=error, context=context, question=question)
        prompt = (
            "Answer the question using only the context below. "
            "If answer is not in context, reply exactly: Not found in provided context.\n\n"
            f"Context:\n{context}\n\nQuestion: {question}"
        )
        response = model.generate_content(prompt)
        answer = (response.text or "").strip()
        if not answer:
            answer = "I could not find a clear answer in the provided context."
        return render_template("qa_result.html", answer=answer)
    except Exception as e:
        return render_template("qa.html", error=f"Question answering failed: {e}", context=context, question=question)



# **Study Plan Generator Page**
def generate_study_plan(syllabus, topics, start_date, deadline, gemini_key=""):
    prompt = f"""
    Create a structured study plan:
    - **Syllabus:** {syllabus}
    - **Topics:** {topics}
    - **Start Date:** {start_date}
    - **Deadline:** {deadline}
    - Weekly & Daily task breakdown.
    """

    try:
        model, error = get_gemini_model(gemini_key)
        if error:
            return None, error
        response = model.generate_content(prompt)
        return response.text, None
    except Exception as e:
        return None, f"Study plan generation failed: {e}"

@app.route("/study-plan", methods=["GET", "POST"])
def study_plan():
    if request.method == "GET":
        return render_template("study_plan.html")

    syllabus = request.form.get("syllabus", "").strip()
    topics = request.form.get("topics", "").strip()
    start_date = request.form.get("start_date", "").strip()
    deadline = request.form.get("deadline", "").strip()
    gemini_key = request.form.get("gemini_api_key", "").strip()

    if not syllabus or not topics or not start_date or not deadline:
        return render_template(
            "study_plan.html",
            error="Please fill in all required fields.",
            syllabus=syllabus,
            topics=topics,
            start_date=start_date,
            deadline=deadline,
            gemini_api_key=gemini_key,
        )

    study_plan_text, error = generate_study_plan(syllabus, topics, start_date, deadline, gemini_key=gemini_key)
    if error:
        return render_template(
            "study_plan.html",
            error=error,
            syllabus=syllabus,
            topics=topics,
            start_date=start_date,
            deadline=deadline,
            gemini_api_key=gemini_key,
        )
    return render_template("study_plan_result.html", study_plan=study_plan_text)

# **Run App**
if __name__ == "__main__":
    app.run(debug=True)
